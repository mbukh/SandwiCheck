export const LOGGED_IN_USER_TIME_OUT_DAYS = 90;

export const ROLES = ["child", "parent"];

export const MAX_USER_NAME_LENGTH = 25;