import { SandwichGallery } from "../components";

const Home = () => {
    // return <SandwichGallery galleryType="best" />;
    return ;
};

export default Home;
