const EXCLUDED_FIELDS = "-password -resetPasswordToken -resetPasswordExpire";

export default EXCLUDED_FIELDS;
