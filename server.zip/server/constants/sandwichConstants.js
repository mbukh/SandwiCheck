export const MAX_INGREDIENTS_COUNT = 10;

export const NO_USER_SANDWICH_USERNAME = "people";

export const MAX_NAME_LENGTH = 25;
export const MAX_COMMENT_LENGTH = 75;
